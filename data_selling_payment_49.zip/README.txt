
# Data Selling Payment - Demo Project

Files:
- index.html
- style.css
- script.js
- qr.png (the QR image you provided)

How to use:
1. Unzip the folder and open index.html in a browser.
2. Click 'Pay ₹49' to open the scanner modal (it shows the QR image).
3. After scanning & paying, click "I've Paid — Show UTR Form" to submit UTR details.
4. This is a frontend demo. To make it production-ready, connect the UTR form to a backend.

Provided values:
- Service ID: 605099281
- UPI ID: 6005099281@mbk
- Amount: ₹49

