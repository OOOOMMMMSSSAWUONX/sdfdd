
// Basic interactivity: show modal with scanner, then on confirm show UTR form
const payBtn = document.getElementById('payBtn');
const modal = document.getElementById('modal');
const closeModal = document.getElementById('closeModal');
const paidBtn = document.getElementById('paidBtn');
const utrSection = document.getElementById('utrSection');
const utrForm = document.getElementById('utrForm');
const utrMsg = document.getElementById('utrMsg');
const refundBtn = document.getElementById('refundBtn');

payBtn.addEventListener('click', ()=>{
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden','false');
});

closeModal.addEventListener('click', ()=>{
  modal.classList.add('hidden');
  modal.setAttribute('aria-hidden','true');
});

paidBtn.addEventListener('click', ()=>{
  modal.classList.add('hidden');
  utrSection.classList.remove('hidden');
  window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'});
});

utrForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const utr = document.getElementById('utr').value.trim();
  const contact = document.getElementById('contact').value.trim();
  if(!name || !utr){ utrMsg.textContent = 'Please enter required fields.'; return; }
  // In real deployment, submit via AJAX to server. Here we just show success message.
  utrMsg.textContent = 'UTR submitted. We will verify and contact you. (Demo mode)';
  utrForm.reset();
});

refundBtn.addEventListener('click', ()=>{
  alert('Refund request received. Please contact support with Service ID 605099281 and your transaction UTR. (Demo)');
});
